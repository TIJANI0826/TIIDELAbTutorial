def balance_check(balance, withdrawal_amount):
  return ()


# a = balance_check(1000, 500)
# print(type(a))
